The shaders in this .zip file support the SRP Batcher, but should not be be used on mobile platforms.
Using these shaders can cause artifacts and issues on mobile phones.

I recommend not using them, as the SRP Batcher is not necessary.